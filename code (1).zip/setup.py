import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="textract-document-extraction",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A tool for extracting information from gas statement PDFs using Amazon Textract",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/sailikhithk/textract-document-extraction",
    packages=setuptools.find_packages(exclude=["tests", "*.tests", "*.tests.*", "tests.*"]),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
    ],
    python_requires=">=3.7",
    install_requires=[
        "boto3>=1.17.0",
        "pdf2jpg>=1.1",
        "python-dotenv>=0.15.0",
        "PyPDF2>=1.26.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.2.3",
            "black>=21.5b1",
            "flake8>=3.9.1",
            "mypy>=0.812",
        ],
    },
    entry_points={
        "console_scripts": [
            "textract-extract=src.main:main",
        ],
    },
)